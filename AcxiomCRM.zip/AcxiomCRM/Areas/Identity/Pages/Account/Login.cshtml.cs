using System.ComponentModel.DataAnnotations;
using AcxiomCRM.Data;
using AcxiomCRM.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
namespace AcxiomCRM.Areas.Identity.Pages.Account;
public class LoginModel : PageModel {
 private readonly SignInManager<IdentityUser> _signIn; private readonly UserManager<IdentityUser> _users; private readonly ApplicationDbContext _db;
 public LoginModel(SignInManager<IdentityUser> signIn,UserManager<IdentityUser> users,ApplicationDbContext db){_signIn=signIn;_users=users;_db=db;}
 [BindProperty] public InputModel Input {get;set;}=new(); [BindProperty(SupportsGet=true)] public string? ReturnUrl {get;set;}
 public void OnGet(string? returnUrl=null){ReturnUrl=returnUrl;}
 public async Task<IActionResult> OnPostAsync(string? returnUrl=null){ReturnUrl=returnUrl??Url.Content("~/");if(!ModelState.IsValid)return Page();var user=await _users.FindByEmailAsync(Input.Email);var result=await _signIn.PasswordSignInAsync(Input.Email,Input.Password,Input.RememberMe,lockoutOnFailure:true);var action=result.Succeeded?"LoginSuccess":result.IsLockedOut?"AccountLockout":"FailedLogin";_db.AuditLogs.Add(new AuditLog{UserId=user?.Id,Action=action,EntityName="IdentityUser",RecordId=user?.Id,CreatedDate=DateTime.UtcNow,IpAddress=HttpContext.Connection.RemoteIpAddress?.ToString()});await _db.SaveChangesAsync();if(result.Succeeded)return LocalRedirect(Url.IsLocalUrl(ReturnUrl)?ReturnUrl! : Url.Content("~/"));if(result.IsLockedOut)ModelState.AddModelError(string.Empty,"This account is locked. Try again later.");else ModelState.AddModelError(string.Empty,"Invalid login attempt.");return Page();}
 public class InputModel{[Required,EmailAddress,Display(Name="Email")]public string Email{get;set;}="";[Required,DataType(DataType.Password)]public string Password{get;set;}="";[Display(Name="Remember me")]public bool RememberMe{get;set;}}
}
