using System.Security.Claims;
using AcxiomCRM.Data;
using AcxiomCRM.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
namespace AcxiomCRM.Areas.Identity.Pages.Account;
public class LogoutModel:PageModel{private readonly SignInManager<IdentityUser> _signIn;private readonly ApplicationDbContext _db;public LogoutModel(SignInManager<IdentityUser> signIn,ApplicationDbContext db){_signIn=signIn;_db=db;}public void OnGet(){}public async Task<IActionResult>OnPostAsync(){_db.AuditLogs.Add(new AuditLog{UserId=User.FindFirstValue(ClaimTypes.NameIdentifier),Action="Logout",EntityName="IdentityUser",RecordId=User.FindFirstValue(ClaimTypes.NameIdentifier),CreatedDate=DateTime.UtcNow,IpAddress=HttpContext.Connection.RemoteIpAddress?.ToString()});await _db.SaveChangesAsync();await _signIn.SignOutAsync();return RedirectToPage("/Account/Login");}}
