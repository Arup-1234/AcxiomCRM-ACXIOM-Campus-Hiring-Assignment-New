using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
namespace AcxiomCRM.Areas.Identity.Pages.Account;
public class RegisterModel : PageModel {
 private readonly UserManager<IdentityUser> _users; private readonly SignInManager<IdentityUser> _signIn;
 public RegisterModel(UserManager<IdentityUser> users,SignInManager<IdentityUser> signIn){_users=users;_signIn=signIn;}
 [BindProperty] public InputModel Input{get;set;}=new();[BindProperty(SupportsGet=true)]public string? ReturnUrl{get;set;}
 public void OnGet(string? returnUrl=null){ReturnUrl=returnUrl;}
 public async Task<IActionResult> OnPostAsync(string? returnUrl=null){ReturnUrl=returnUrl??Url.Content("~/");if(!ModelState.IsValid)return Page();var user=new IdentityUser{UserName=Input.Email,Email=Input.Email,EmailConfirmed=true,LockoutEnabled=true};var result=await _users.CreateAsync(user,Input.Password);if(result.Succeeded){await _users.AddToRoleAsync(user,"Sales Executive");await _signIn.SignInAsync(user,isPersistent:false);return LocalRedirect(Url.IsLocalUrl(ReturnUrl)?ReturnUrl!:Url.Content("~/"));}foreach(var error in result.Errors)ModelState.AddModelError(string.Empty,error.Description);return Page();}
 public class InputModel{[Required,EmailAddress]public string Email{get;set;}="";[Required,DataType(DataType.Password),StringLength(100,MinimumLength=8)]public string Password{get;set;}="";[Required,DataType(DataType.Password),Compare(nameof(Password),ErrorMessage="Passwords do not match.")]public string ConfirmPassword{get;set;}="";}
}
