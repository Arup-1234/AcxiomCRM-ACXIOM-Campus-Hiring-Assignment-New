using AcxiomCRM.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace AcxiomCRM.Data;
public class ApplicationDbContext : IdentityDbContext<IdentityUser> {
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }
    public DbSet<Customer> Customers => Set<Customer>();
    public DbSet<Lead> Leads => Set<Lead>();
    public DbSet<Opportunity> Opportunities => Set<Opportunity>();
    public DbSet<FollowUp> FollowUps => Set<FollowUp>();
    public DbSet<Activity> Activities => Set<Activity>();
    public DbSet<AuditLog> AuditLogs => Set<AuditLog>();
    protected override void OnModelCreating(ModelBuilder builder) {
        base.OnModelCreating(builder);
        builder.Entity<Customer>().HasIndex(x => x.Email).IsUnique();
        builder.Entity<Customer>().HasIndex(x => x.Phone).IsUnique();
        builder.Entity<Lead>().HasIndex(x => x.LeadCode).IsUnique();
        builder.Entity<Customer>().Property(x => x.CustomerCode).HasMaxLength(20).IsRequired();
        builder.Entity<Lead>().Property(x => x.LeadCode).HasMaxLength(20).IsRequired();
        builder.Entity<Opportunity>().Property(x => x.Amount).HasPrecision(18,2);
        builder.Entity<Lead>().Property(x => x.ExpectedValue).HasPrecision(18,2);
        builder.Entity<Customer>().HasMany(x => x.Opportunities).WithOne(x => x.Customer).HasForeignKey(x => x.CustomerId).OnDelete(DeleteBehavior.SetNull);
        builder.Entity<Customer>().HasMany(x => x.FollowUps).WithOne(x => x.Customer).HasForeignKey(x => x.CustomerId).OnDelete(DeleteBehavior.SetNull);
        builder.Entity<Lead>().HasMany(x => x.Opportunities).WithOne(x => x.Lead).HasForeignKey(x => x.LeadId).OnDelete(DeleteBehavior.SetNull);
        builder.Entity<Lead>().HasMany(x => x.FollowUps).WithOne(x => x.Lead).HasForeignKey(x => x.LeadId).OnDelete(DeleteBehavior.SetNull);
    }
}
