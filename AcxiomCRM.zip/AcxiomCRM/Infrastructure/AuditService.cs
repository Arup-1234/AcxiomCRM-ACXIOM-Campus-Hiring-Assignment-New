using System.Text.Json;
using AcxiomCRM.Data;
using AcxiomCRM.Models;
using System.Security.Claims;
namespace AcxiomCRM.Infrastructure;
public class AuditService {
    private readonly ApplicationDbContext _db; private readonly IHttpContextAccessor _http;
    public AuditService(ApplicationDbContext db, IHttpContextAccessor http) { _db=db; _http=http; }
    public async Task WriteAsync(string action, string? entity=null, object? recordId=null, object? oldValue=null, object? newValue=null) {
        var context = _http.HttpContext;
        _db.AuditLogs.Add(new AuditLog { UserId=context?.User.FindFirstValue(ClaimTypes.NameIdentifier), Action=action, EntityName=entity, RecordId=recordId?.ToString(), OldValue=Serialize(oldValue), NewValue=Serialize(newValue), IpAddress=context?.Connection.RemoteIpAddress?.ToString(), CreatedDate=DateTime.UtcNow });
        await _db.SaveChangesAsync();
    }
    private static string? Serialize(object? value) { if(value is null) return null; try { var s=JsonSerializer.Serialize(value); return s.Length>4000?s[..4000]:s; } catch { return value.ToString(); } }
}
