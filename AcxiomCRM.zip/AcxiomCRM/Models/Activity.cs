using System.ComponentModel.DataAnnotations;
namespace AcxiomCRM.Models;
public class Activity {
    public int ActivityId { get; set; }
    [Required, StringLength(120)] public string Title { get; set; } = "";
    [Required] public string ActivityType { get; set; } = "Note";
    [StringLength(2000)] public string? Description { get; set; }
    public DateTime CreatedDate { get; set; } = DateTime.UtcNow;
    public string? CreatedBy { get; set; }
    public int? CustomerId { get; set; }
}
