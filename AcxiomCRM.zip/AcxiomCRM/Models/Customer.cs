using System.ComponentModel.DataAnnotations;
namespace AcxiomCRM.Models;
public class Customer {
    public int CustomerId { get; set; }
    [Required, StringLength(20)] public string CustomerCode { get; set; } = "";
    [Required, StringLength(120)] public string CustomerName { get; set; } = "";
    [Required, EmailAddress, StringLength(254)] public string Email { get; set; } = "";
    [Required, Phone, StringLength(20, MinimumLength=7)] public string Phone { get; set; } = "";
    [Required, StringLength(120)] public string CompanyName { get; set; } = "";
    [StringLength(250)] public string? Address { get; set; }
    [StringLength(80)] public string? City { get; set; }
    [StringLength(80)] public string? State { get; set; }
    [Required] public string Status { get; set; } = "Active";
    public DateTime CreatedDate { get; set; } = DateTime.UtcNow;
    public string? CreatedBy { get; set; }
    public ICollection<Opportunity> Opportunities { get; set; } = new List<Opportunity>();
    public ICollection<FollowUp> FollowUps { get; set; } = new List<FollowUp>();
}
