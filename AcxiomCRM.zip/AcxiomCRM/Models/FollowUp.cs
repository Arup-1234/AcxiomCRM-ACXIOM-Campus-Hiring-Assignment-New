using System.ComponentModel.DataAnnotations;
namespace AcxiomCRM.Models;
public class FollowUp {
    public int FollowUpId { get; set; }
    public int? CustomerId { get; set; } public Customer? Customer { get; set; }
    public int? LeadId { get; set; } public Lead? Lead { get; set; }
    [Required, DataType(DataType.DateTime)] public DateTime FollowUpDate { get; set; } = DateTime.Today.AddDays(1);
    [Required] public string FollowUpType { get; set; } = "Call";
    [StringLength(1000)] public string? Remarks { get; set; }
    [Required] public string Status { get; set; } = "Planned";
    public string? AssignedTo { get; set; }
}
