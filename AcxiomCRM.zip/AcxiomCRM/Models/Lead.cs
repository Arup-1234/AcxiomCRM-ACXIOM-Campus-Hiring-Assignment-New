using System.ComponentModel.DataAnnotations;
namespace AcxiomCRM.Models;
public class Lead {
    public int LeadId { get; set; }
    [Required, StringLength(20)] public string LeadCode { get; set; } = "";
    [Required, StringLength(120)] public string LeadName { get; set; } = "";
    [EmailAddress, StringLength(254)] public string? Email { get; set; }
    [Phone, StringLength(20)] public string? Phone { get; set; }
    [StringLength(120)] public string? CompanyName { get; set; }
    [StringLength(60)] public string Source { get; set; } = "Website";
    [Required] public string Status { get; set; } = "New";
    [Range(0, 999999999)] public decimal ExpectedValue { get; set; }
    public DateTime CreatedDate { get; set; } = DateTime.UtcNow;
    public string? AssignedTo { get; set; }
    public ICollection<Opportunity> Opportunities { get; set; } = new List<Opportunity>();
    public ICollection<FollowUp> FollowUps { get; set; } = new List<FollowUp>();
}
