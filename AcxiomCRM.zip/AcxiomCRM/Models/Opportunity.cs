using System.ComponentModel.DataAnnotations;
namespace AcxiomCRM.Models;
public class Opportunity {
    public int OpportunityId { get; set; }
    [Required, StringLength(120)] public string OpportunityName { get; set; } = "";
    public int? CustomerId { get; set; } public Customer? Customer { get; set; }
    public int? LeadId { get; set; } public Lead? Lead { get; set; }
    [Range(typeof(decimal), "0.01", "999999999")] public decimal Amount { get; set; }
    [Required] public string Stage { get; set; } = "Qualification";
    [Range(0,100)] public int Probability { get; set; } = 10;
    [DataType(DataType.Date)] public DateTime ExpectedCloseDate { get; set; } = DateTime.Today.AddDays(30);
    [Required] public string Status { get; set; } = "Open";
    public DateTime CreatedDate { get; set; } = DateTime.UtcNow;
    public string? AssignedTo { get; set; }
}
